### Hexlet tests and linter status:
[![Actions Status](https://github.com/MaukhetdinovEF/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/MaukhetdinovEF/python-project-49/actions)
<a href="https://codeclimate.com/github/MaukhetdinovEF/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8a265b39ccc530d0c852/maintainability" /></a>
